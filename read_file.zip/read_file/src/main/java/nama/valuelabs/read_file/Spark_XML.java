package nama.valuelabs.read_file;


import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

public class Spark_XML {
	
	public static void main(String [] args){
		System.setProperty("hadoop.home.dir", "D:/hadoop");
		JavaSparkContext sc=	SparkContextUtils.getSparkJavaContextUtils();
		 JavaRDD<String> lines = sc.textFile("input.txt");
		 lines.coalesce(1).saveAsTextFile("output");
	}
}
